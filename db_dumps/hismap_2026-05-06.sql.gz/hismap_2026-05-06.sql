--
-- PostgreSQL database dump
--

\restrict Zzv2nr9AwbTjk1Pzr4ie5jXL3hd0XLvfIdjTJTgPwRedVUhHwB2zWzM44fSq9zC

-- Dumped from database version 16.13 (Homebrew)
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: authors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authors (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    dynasty character varying(50),
    birth_year integer,
    death_year integer,
    biography text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: authors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.authors_id_seq OWNED BY public.authors.id;


--
-- Name: books; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.books (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    author character varying(200),
    dynasty character varying(50),
    era_start integer,
    era_end integer,
    description text,
    source_text text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: books_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.books_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: books_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.books_id_seq OWNED BY public.books.id;


--
-- Name: entry_authors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entry_authors (
    entry_id integer NOT NULL,
    author_id integer NOT NULL
);


--
-- Name: entry_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entry_locations (
    entry_id integer NOT NULL,
    location_id integer NOT NULL,
    location_order integer NOT NULL,
    importance integer DEFAULT 0 NOT NULL
);


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    book_id integer,
    title character varying(500) NOT NULL,
    original_text text NOT NULL,
    chapter_reference character varying(200),
    keywords json,
    keyword_annotations json,
    era_context text,
    political_context text,
    religious_context text,
    social_environment text,
    visit_date_approximate character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    credibility json,
    annotations json,
    excerpt_original text,
    excerpt_translation text,
    summary_chinese text,
    summary_english text,
    persons json,
    dates json
);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    modern_name character varying(200),
    ancient_name character varying(200),
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    location_type character varying(50),
    ancient_region character varying(200),
    one_line_summary text,
    location_rationale text,
    academic_disputes text,
    credibility_notes text,
    today_remains text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    geo_certainty character varying(32),
    certainty_note text
);


--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: relation_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relation_locations (
    id integer NOT NULL,
    from_location_id integer NOT NULL,
    to_location_id integer NOT NULL,
    relation_type character varying(100) NOT NULL,
    description text
);


--
-- Name: relation_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.relation_locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relation_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.relation_locations_id_seq OWNED BY public.relation_locations.id;


--
-- Name: authors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authors ALTER COLUMN id SET DEFAULT nextval('public.authors_id_seq'::regclass);


--
-- Name: books id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books ALTER COLUMN id SET DEFAULT nextval('public.books_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: relation_locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relation_locations ALTER COLUMN id SET DEFAULT nextval('public.relation_locations_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
006
\.


--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authors (id, name, dynasty, birth_year, death_year, biography, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.books (id, title, author, dynasty, era_start, era_end, description, source_text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: entry_authors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entry_authors (entry_id, author_id) FROM stdin;
\.


--
-- Data for Name: entry_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entry_locations (entry_id, location_id, location_order, importance) FROM stdin;
5	1	0	0
5	2	1	0
5	3	2	0
5	4	3	0
5	5	4	0
5	6	5	0
5	7	6	0
6	8	0	0
6	9	1	0
7	10	0	0
8	11	0	0
8	12	1	0
8	13	2	0
8	14	3	0
9	11	0	0
9	13	1	0
9	15	2	0
9	16	3	0
9	17	4	0
9	18	5	0
9	19	6	0
9	20	7	0
9	21	8	0
9	22	9	0
9	23	10	0
10	24	0	0
10	25	1	0
10	26	2	0
10	22	3	0
10	15	4	0
10	16	5	0
10	11	6	0
10	27	7	0
10	28	8	0
10	29	9	0
11	25	0	0
11	30	1	0
11	31	2	0
12	32	0	0
12	33	1	0
12	34	2	0
12	35	3	0
12	36	4	0
12	37	5	0
12	38	6	0
12	12	7	0
12	39	8	0
13	40	0	0
13	41	1	0
14	42	0	0
14	43	1	0
14	44	2	0
14	45	3	0
14	46	4	0
14	47	5	0
14	48	6	0
14	49	7	0
15	42	0	0
15	50	1	0
15	51	2	0
15	52	3	0
16	51	0	0
16	53	1	0
16	54	2	0
16	55	3	0
16	56	4	0
16	57	5	0
16	58	6	0
16	59	7	0
16	60	8	0
16	61	9	0
16	62	10	0
16	63	11	0
16	64	12	0
16	65	13	0
16	66	14	0
16	67	15	0
16	68	16	0
16	69	17	0
16	70	18	0
16	71	19	0
16	72	20	0
16	73	21	0
16	74	22	0
16	75	23	0
16	42	24	0
16	76	25	0
16	77	26	0
16	78	27	0
16	79	28	0
16	80	29	0
16	81	30	0
16	82	31	0
16	83	32	0
16	84	33	0
16	85	34	0
16	86	35	0
16	87	36	0
16	88	37	0
16	89	38	0
16	90	39	0
16	91	40	0
16	25	41	0
17	25	0	0
18	92	0	0
18	93	1	0
19	94	0	0
19	95	1	0
19	96	2	0
20	97	0	0
20	43	1	0
20	64	2	0
20	98	3	0
20	99	4	0
20	100	5	0
20	101	6	0
20	102	7	0
21	11	0	0
23	103	0	0
25	104	0	0
26	42	0	0
26	64	1	0
28	11	0	0
28	22	1	0
28	13	2	0
28	105	3	0
29	40	0	0
29	41	1	0
29	106	2	0
29	107	3	0
29	108	4	0
29	109	5	0
29	110	6	0
29	111	7	0
29	112	8	0
30	113	0	0
30	20	1	0
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, book_id, title, original_text, chapter_reference, keywords, keyword_annotations, era_context, political_context, religious_context, social_environment, visit_date_approximate, created_at, updated_at, credibility, annotations, excerpt_original, excerpt_translation, summary_chinese, summary_english, persons, dates) FROM stdin;
1	\N	Segment 1	pipeline/output/peregrinac-a-o/peregrinac-a-o-pt-001.json	\N	null	\N	\N	\N	\N	\N	\N	2026-05-05 21:07:40.959252+08	2026-05-05 21:07:40.959252+08	null	null	\N	\N	\N	\N	null	null
2	\N	Segment 2	pipeline/output/peregrinac-a-o/peregrinac-a-o-pt-002.json	\N	null	\N	\N	\N	\N	\N	\N	2026-05-05 21:07:40.959252+08	2026-05-05 21:07:40.959252+08	null	null	\N	\N	\N	\N	null	null
3	\N	Segment 3	pipeline/output/peregrinac-a-o/peregrinac-a-o-pt-003.json	\N	null	\N	\N	\N	\N	\N	\N	2026-05-05 21:07:40.959252+08	2026-05-05 21:07:40.959252+08	null	null	\N	\N	\N	\N	null	null
4	\N	Segment 4	pipeline/output/peregrinac-a-o/peregrinac-a-o-pt-004.json	\N	null	\N	\N	\N	\N	\N	\N	2026-05-05 21:07:40.959252+08	2026-05-05 21:07:40.959252+08	null	null	\N	\N	\N	\N	null	null
5	\N	Introduction to the Author's Travels	pipeline/output/peregrinac-a-o/peregrinac-a-o-pt-001.json	Chapter 1	["Portuguese exploration", "16th century", "travel narrative", "captivity", "religious reflection"]	\N	Early 16th century, Age of Discovery.	Portuguese maritime expansion and trade in Asia.	Catholic faith as a driving force and source of solace.	Life of a soldier and adventurer in foreign lands, marked by hardship and survival.	1537-1558	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	{"era_context": "Early 16th century, Age of Discovery.", "political_context": "Portuguese maritime expansion and trade in Asia.", "religious_context": "Catholic faith as a driving force and source of solace.", "social_environment": "Life of a soldier and adventurer in foreign lands, marked by hardship and survival.", "credibility_score": 0.7, "notes": "The text is a first-person account, but known for its exaggerations and fantastical elements. It reflects the author's personal perspective and religious worldview."}	null	Quando às vezes ponho diante dos olhos os muitos e grandes trabalhos e infortúnios que por mim passaram, começados no princípio da minha primeira idade e continuados pela maior parte e melhor tempo da minha vida, acho que com muita razão me posso queixar da ventura que parece que tomou por particular tenção e empresa sua perseguir-me e maltratar-me.	When I sometimes place before my eyes the many and great labors and misfortunes that I have passed through, begun at the beginning of my early age and continued for most and the best part of my life, I find that I have much reason to complain of fortune, which seems to have taken it as its particular intention and enterprise to persecute and mistreat me.	这是费尔南·门德斯·平托《朝圣》一书的开篇自述。作者回顾了自己从青年时期开始的漫长而艰辛的旅程，包括在印度、埃塞俄比亚、阿拉伯、中国等地的遭遇。他提到自己曾被俘虏13次，被贩卖17次，历时21年。他写作的目的是为了给子女留下记录，让他们了解父亲的苦难与上帝的恩典。	This is the opening self-narration of Fernão Mendes Pinto's 'Peregrinação'. The author reflects on his long and arduous journey beginning in his youth, including experiences in India, Ethiopia, Arabia, China, etc. He mentions being captured 13 times and sold 17 times over 21 years. His purpose in writing is to leave a record for his children, so they may understand their father's sufferings and God's grace.	["Fern\\u00e3o Mendes Pinto"]	[]
6	\N	Recolhimento de Fazenda e Libertação de Escravos	pipeline/output/peregrinac-a-o/peregrinac-a-o-pt-002.json	Chapter 2	["Portuguese maritime exploration", "16th century", "piracy", "slave trade", "China coast"]	\N	Early 16th century, during the Age of Discovery and Portuguese expansion in Asia.	Portuguese Estado da Índia was establishing trade routes and outposts, often engaging in conflict with local powers and other European rivals.	Christian (Catholic) context, with references to God, prayer, and religious ceremonies.	Hierarchical society with clear distinctions between captains, soldiers, and slaves; practices of ransom and liberation.	1540-1545	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	{"era_context": "Early 16th century, during the Age of Discovery and Portuguese expansion in Asia.", "political_context": "Portuguese Estado da \\u00cdndia was establishing trade routes and outposts, often engaging in conflict with local powers and other European rivals.", "religious_context": "Christian (Catholic) context, with references to God, prayer, and religious ceremonies.", "social_environment": "Hierarchical society with clear distinctions between captains, soldiers, and slaves; practices of ransom and liberation.", "credibility_score": 0.8, "notes": "The account is detailed and plausible for the period, though likely embellished for narrative effect. It reflects common practices of the time, such as the treatment of captives and the distribution of spoils."}	null	Recolhendo-se após isto, António de Faria, para a sua embarcação, não atendeu aquele dia a mais que visitar e prover os feridos, e agasalhar os soldados, por ser já quase noite; e quando ao outro dia foi manhã clara, foi ao junco grande que tinha tomado, o qual estava ainda cheio de corpos mortos do dia anterior, e mandando-os lançar todos ao mar.	After this, António de Faria returned to his ship, spending the day only visiting and tending to the wounded and sheltering the soldiers, as it was already almost night; and when the next day was clear morning, he went to the large junk he had taken, which was still full of dead bodies from the previous day, and ordered them all thrown into the sea.	安东尼奥·德·法里亚在战斗后返回船上，照料伤员。第二天早晨，他前往缴获的大型中国帆船，命令将所有尸体抛入海中，并为敌方首领举行葬礼。随后，他释放了所有奴隶和俘虏，并承诺用个人财产补偿他们的主人。	António de Faria returned to his ship after the battle to tend to the wounded. The next morning, he went to the captured junk, ordered all the dead bodies thrown into the sea, and gave a burial to the enemy leader. He then freed all slaves and captives, promising to compensate their owners from his own wealth.	["Ant\\u00f3nio de Faria", "Coja Ac\\u00e9m"]	[]
7	\N	Costa da China	pipeline/output/peregrinac-a-o/peregrinac-a-o-pt-004.json	Chapter 4	["Portuguese exploration", "piracy", "Ming Dynasty China", "maritime raid", "16th century"]	\N	Early 16th century Portuguese maritime expansion and privateering in Asian waters.	Ming Dynasty China, with internal instability and conflict.	Christian Portuguese expedition operating in a non-Christian land.	Maritime raiding and plunder were common practices for Portuguese expeditions seeking wealth.	1540-1545	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	{"era_context": "Early 16th century Portuguese maritime expansion and privateering in Asian waters.", "political_context": "Ming Dynasty China, with internal instability and conflict.", "religious_context": "Christian Portuguese expedition operating in a non-Christian land.", "social_environment": "Maritime raiding and plunder were common practices for Portuguese expeditions seeking wealth.", "credibility_score": 0.7, "notes": "The account is from a historical travel journal, likely embellished but based on real events of Portuguese privateering in China."}	null	Vendo António de Faria que era já passada mais de hora e meia, mandou com muita pressa recolher a gente... mandou pôr fogo à cidade por dez ou doze partes, e como a maior parte dela era de tabuado de pinho e de outra madeira, em menos de um quarto de hora ardeu tão bravamente que parecia coisa do inferno.	Seeing that more than an hour and a half had passed, António de Faria ordered the people to be gathered with great haste... he ordered the city to be set on fire in ten or twelve places, and as most of it was made of pine planks and other wood, in less than a quarter of an hour it burned so fiercely that it seemed like something from hell.	安东尼奥·德·法里亚在完成对城市的掠夺后，下令纵火焚烧城市，随后带领船员和俘虏安全登船撤离。他们满载财富和年轻女子，扬帆而去。	After completing the sack of the city, António de Faria ordered it to be set on fire in multiple places, causing it to burn fiercely. He then led his men and captives to the beach, where they boarded their ships without opposition, departing with great riches and many beautiful young women.	["Ant\\u00f3nio de Faria"]	[]
8	\N	Marco Polo: Biography and Overview	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-001.json	Introduction	["Mongol Empire", "Venetian merchant", "Khubilai Khan", "medieval travel", "Cathay"]	\N	13th century Mongol Empire and Venetian trade network	Mongol expansion and Pax Mongolica; Venice as major maritime republic	Christian-Mongol diplomatic relations; papal envoy missions	Merchant class mobility; cultural exchange between East and West	1254 - 1324	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th century Mongol Empire and Venetian trade network", "political_context": "Mongol expansion and Pax Mongolica; Venice as major maritime republic", "religious_context": "Christian-Mongol diplomatic relations; papal envoy missions", "social_environment": "Merchant class mobility; cultural exchange between East and West", "credibility_score": 0.8, "notes": "This is modern scholarly introduction summarizing historical facts. Dates and events align with known historical records about Marco Polo's life and travels."}	null	MARCO POLO was born in 1254, the son of Niccolò Polo, a Venetian merchant. A few years later his father and uncle set out across the Black Sea on a business venture, only to find themselves caught up in a Mongol civil war and unable to return home. Eventually they joined an envoy headed to the Mongol ruler Khubilai Khan, who quizzed them and sent them as his emissaries to the pope. In 1269 they reached Venice and Niccolò was reunited with his fifteen-year-old son Marco, who joined them when they set out again for the East in 1271. The journey would last for twenty-four years. Marco quickly learned the Mongol Empire’s languages and customs and by his own testimony became a favoured agent of Khubilai Khan, who sent him from his court at Beijing on long missions and enjoyed the detailed reports he made on his return.	MARCO POLO was born in 1254, the son of Niccolò Polo, a Venetian merchant. A few years later his father and uncle set out across the Black Sea on a business venture, only to find themselves caught up in a Mongol civil war and unable to return home. Eventually they joined an envoy headed to the Mongol ruler Khubilai Khan, who quizzed them and sent them as his emissaries to the pope. In 1269 they reached Venice and Niccolò was reunited with his fifteen-year-old son Marco, who joined them when they set out again for the East in 1271. The journey would last for twenty-four years. Marco quickly learned the Mongol Empire’s languages and customs and by his own testimony became a favoured agent of Khubilai Khan, who sent him from his court at Beijing on long missions and enjoyed the detailed reports he made on his return.	这段文字介绍了马可·波罗的生平：他于1254年出生于威尼斯商人家庭，父亲和叔叔因蒙古内战滞留东方，后成为忽必烈汗的使者。1271年马可随父东行，在蒙古帝国服务24年，精通语言习俗，受忽必烈器重，执行多次长途任务并提交详细报告。	This passage introduces Marco Polo's life: born in 1254 to a Venetian merchant family, his father and uncle were stranded in the East due to Mongol civil war and became emissaries of Khubilai Khan. In 1271 Marco traveled east with his father, served the Mongol Empire for 24 years, mastered languages and customs, was favored by Khubilai Khan, and executed long-distance missions with detailed reports.	["Marco Polo", "Niccol\\u00f2 Polo", "Khubilai Khan", "Pope"]	["1254-01-01", "1269-01-01", "1271-01-01", "1295-01-01", "1324-01-01"]
9	\N	Introduction	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-002.json	Introduction	["travel literature", "medieval history", "Mongol Empire", "literary analysis", "historical debate"]	\N	Modern scholarly analysis of a medieval text.	Analysis of the relationship between medieval European states (Venice, Genoa, Papacy) and the Mongol Empire.	Discussion of the book's portrayal of various religions (Christianity, Islam, Buddhism) and its impact on Western Christian perceptions.	Focus on the intellectual and cultural impact of the book on the European worldview.	1271 - 1295	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "Modern scholarly analysis of a medieval text.", "political_context": "Analysis of the relationship between medieval European states (Venice, Genoa, Papacy) and the Mongol Empire.", "religious_context": "Discussion of the book's portrayal of various religions (Christianity, Islam, Buddhism) and its impact on Western Christian perceptions.", "social_environment": "Focus on the intellectual and cultural impact of the book on the European worldview.", "credibility_score": 0.9, "notes": "The introduction presents a balanced academic overview, acknowledging both the book's historical significance and the scholarly debates surrounding its authorship and veracity."}	null	The Travels of Marco Polo may be the most famous travel book ever written... Few books can truly be said to have changed the world; for all its naysayers, Marco Polo’s Travels is one of them.	The Travels of Marco Polo may be the most famous travel book ever written... Few books can truly be said to have changed the world; for all its naysayers, Marco Polo’s Travels is one of them.	引言讨论了《马可·波罗游记》作为一部著名旅行文学作品的独特性质、其成书过程（由马可·波罗在狱中口述，鲁斯蒂谦记录润色）、文本版本的复杂性，以及后世对其真实性的持续争论。最后，引言强调了马可·波罗作为第一位向欧洲详细描述东方文明的旅行者的历史重要性。	The introduction discusses the unique nature of The Travels as a famous travel book, its creation process (dictated by Marco Polo in prison, recorded and polished by Rustichello), the complexity of the manuscript tradition, and the ongoing historical debate about its veracity. It concludes by emphasizing Marco Polo's historical importance as the first European to provide a detailed account of Eastern civilizations.	["Marco Polo", "Rustichello of Pisa", "Khubilai Khan", "Genghis Khan", "Edward I of England", "Frances Wood", "Christopher Columbus", "Strabo", "Jacopo d'Acqui", "Niccol\\u00f2 Polo", "Maffeo Polo"]	[]
10	\N	The Middle East	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-003.json	Chapter 1: The Middle East	["Roman trade", "Indian Ocean", "Silk Road", "Medieval cartography", "Christian Europe"]	\N	Text describes the transition from Roman to Islamic dominance in global trade routes from the 1st to the 7th centuries AD, and the subsequent medieval European worldview.	Covers the decline of Roman power, the rise of Arab caliphates (Abbasid), and the fragmented European merchant states competing at Constantinople.	Mentions the spread of Islam and the Christian framing of geography in medieval European maps.	Depicts a world of long-distance trade, with European merchants dependent on intermediaries and lacking direct knowledge of Eastern origins of goods.	1st century AD - 14th century AD	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "Text describes the transition from Roman to Islamic dominance in global trade routes from the 1st to the 7th centuries AD, and the subsequent medieval European worldview.", "political_context": "Covers the decline of Roman power, the rise of Arab caliphates (Abbasid), and the fragmented European merchant states competing at Constantinople.", "religious_context": "Mentions the spread of Islam and the Christian framing of geography in medieval European maps.", "social_environment": "Depicts a world of long-distance trade, with European merchants dependent on intermediaries and lacking direct knowledge of Eastern origins of goods.", "credibility_score": 0.8, "notes": "The excerpt is part of a historical introduction summarizing established historical facts about trade and cultural perceptions. The mention of the 'Periplus of the Erythraean Sea' is a specific historical source. The description of medieval maps reflects known historical cartography."}	null	As many as 120 Roman freighters a year were crossing the Indian Ocean on the monsoon winds; the first-century AD sailing guide known as the Periplus of the Erythraean Sea describes a thriving trade conducted at ports along India’s western and southern shores. There the Romans reached their limit; as to all the gold that disappeared along the caravan routes of Central Asia to pay for that other essential luxury, Chinese silk, they only had the vaguest idea where it ended up.	As many as 120 Roman freighters a year were crossing the Indian Ocean on the monsoon winds; the first-century AD sailing guide known as the Periplus of the Erythraean Sea describes a thriving trade conducted at ports along India’s western and southern shores. There the Romans reached their limit; as to all the gold that disappeared along the caravan routes of Central Asia to pay for that other essential luxury, Chinese silk, they only had the vaguest idea where it ended up.	本段描述了公元一世纪时，罗马商船利用季风每年多达120艘穿越印度洋进行贸易的盛况，以及罗马人对亚洲内陆和中国丝绸来源的模糊认知。随后概述了从罗马帝国衰落、阿拉伯商人崛起，到伊斯兰教扩张导致西方与东方贸易中断的历史进程，最终只剩下君士坦丁堡作为基督教世界连接香料与丝绸商路的终点。西方基督世界因与外部世界隔绝，开始在地图上重新想象亚洲，将耶路撒冷置于中心，并融合了诸多圣经地点与传说。	This passage describes the thriving Roman trade across the Indian Ocean in the first century AD, where up to 120 freighters per year used the monsoon winds, and the Romans' vague understanding of Central Asia and the source of Chinese silk. It then summarizes the historical progression from the decline of Roman power, the rise of Arab traders, and the expansion of Islam in the seventh century, which ultimately cut the West off from the East, leaving Constantinople as the only Christian terminus for the spice and silk caravans. Isolated from firsthand knowledge, Western Christendom reimagined Asia on its maps, placing Jerusalem at the center and incorporating biblical locations and legends.	["Noah", "Magi"]	["1st century AD", "3rd century AD", "7th century"]
11	\N	Marco Polo's Travels - Chapter 4/34: The Middle East	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-004.json	Chapter 4: From Beijing to Bengal, 1275–1291	["Alexander the Great", "Alexander Romance", "medieval imagination", "monstrous races", "eastern speculation"]	\N	The passage discusses medieval European perceptions of the East, rooted in classical legends like the Alexander Romance and religious histories like the Crusades.	Europe was fragmented, with the Crusades having recently ended, and Islamic powers controlling the Eastern Mediterranean.	Christian Europe was influenced by religious narratives and myths about the East, often conflating geographical and spiritual concepts.	Medieval European society was characterized by limited direct knowledge of Asia, relying on travelers' tales, religious texts, and classical works.	1275-1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "The passage discusses medieval European perceptions of the East, rooted in classical legends like the Alexander Romance and religious histories like the Crusades.", "political_context": "Europe was fragmented, with the Crusades having recently ended, and Islamic powers controlling the Eastern Mediterranean.", "religious_context": "Christian Europe was influenced by religious narratives and myths about the East, often conflating geographical and spiritual concepts.", "social_environment": "Medieval European society was characterized by limited direct knowledge of Asia, relying on travelers' tales, religious texts, and classical works.", "credibility_score": 0.6, "notes": "This section is part of the introduction/analysis in Nigel Cliff's translation, describing historical and literary context for Marco Polo's travels. It blends factual historical references (e.g., Benjamin of Tudela, Crusades) with medieval myths and legends, offering a scholarly overview rather than a firsthand account."}	[{"note": "This entry covers the introductory analysis of medieval European views of the East, setting the stage for Marco Polo's journey."}]	Alexander the Great was said to have confined them behind a pair of colossal Iron Gates. Alexander’s campaigns in India, embellished by the medieval imagination and recounted in the immensely popular Alexander Romance, were another source of intense speculation about the East.	Alexander the Great was said to have confined them behind a pair of colossal Iron Gates. Alexander’s campaigns in India, embellished by the medieval imagination and recounted in the immensely popular Alexander Romance, were another source of intense speculation about the East.	本段讲述了亚历山大大帝的印度战役如何通过《亚历山大传奇》在中世纪被想象和传播，激发了欧洲人对东方的强烈猜想。文中提到了如犬头人、胸面人等传说中的怪物种族，以及人们对印度（常与东方同义）的模糊认知。	This passage describes how Alexander the Great's campaigns in India were imagined and propagated in the Middle Ages through the Alexander Romance, fueling intense European speculation about the East. It mentions legendary monstrous races like the Cynocephali and Blemmyae, and the blurred European perception of India as synonymous with the East.	["Alexander the Great", "Benjamin of Tudela"]	[]
12	\N	The Middle East	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-005.json	Chapter 1	["Armenia", "Tartars", "Georgia", "Christianity", "Silk Trade"]	\N	13th-century Mongol-dominated world, during the Pax Mongolica.	The Mongol Empire's fragmentation and vassalage in the Middle East, with local rulers subject to the Great Khan or regional Tartar lords.	Coexistence of Christianity (Armenian, Georgian, Nestorian), Islam, and ancient beliefs; religious tensions and conversions.	A world of trade routes, ethnic diversity, and cultural exchange, but also instability and health hazards.	1260-1295	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th-century Mongol-dominated world, during the Pax Mongolica.", "political_context": "The Mongol Empire's fragmentation and vassalage in the Middle East, with local rulers subject to the Great Khan or regional Tartar lords.", "religious_context": "Coexistence of Christianity (Armenian, Georgian, Nestorian), Islam, and ancient beliefs; religious tensions and conversions.", "social_environment": "A world of trade routes, ethnic diversity, and cultural exchange, but also instability and health hazards.", "credibility_score": 0.7, "notes": "Contains vivid descriptions and legendary elements (Noah's Ark, miraculous fish) mixed with firsthand observation, reflecting medieval travel writing conventions."}	null	The fact is that there are two Armenias, the Greater and the Lesser. The lord of Lesser Armenia is a king who rules his country with wisdom and justice and is subject to the Tartars. ... Now let us leave Greater Armenia and speak of the province of Georgia.	The fact is that there are two Armenias, the Greater and the Lesser. The lord of Lesser Armenia is a king who rules his country with wisdom and justice and is subject to the Tartars. ... Now let us leave Greater Armenia and speak of the province of Georgia.	本段描述了亚美尼亚的两个部分：小亚美尼亚和大亚美尼亚。小亚美尼亚有国王统治，但臣服于鞑靼人，盛产商品但气候不健康；大亚美尼亚幅员辽阔，是鞑靼军队的夏季牧场，拥有著名的诺亚方舟山和富含石油的泉眼。	This segment describes the two parts of Armenia: Lesser and Greater. Lesser Armenia is ruled by a king but subject to the Tartars, prosperous but unhealthy; Greater Armenia is a vast province serving as a summer pasture for Tartar armies, home to the legendary Mountain of Noah's Ark and a spring that gushes oil.	["Alexander the Great", "David Malik"]	[]
13	\N	The Road to Cathay	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-006.json	Chapter Two	["travel", "Central Asia", "Islam", "Tartars", "trade"]	\N	13th century during the Mongol Empire	Mongol control over various regions	Predominantly Islamic worship	Trade routes and nomadic movements	1271 - 1295	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th century during the Mongol Empire", "political_context": "Mongol control over various regions", "religious_context": "Predominantly Islamic worship", "social_environment": "Trade routes and nomadic movements", "credibility_score": 0.7, "notes": "Based on Marco Polo's firsthand observations, but with potential embellishments common in travel accounts."}	null	When the traveller leaves this castle, he rides through beautiful plains and valleys and hills covered with lush grass that provide fine pasture, plenty of fruit and all things in great abundance. After riding for six days, he reaches Sheberghan, a city rich with melons and game, then moves to Balkh, a large city ruined by Tartars but once boasting palaces.	When the traveller leaves this castle, he rides through beautiful plains and valleys and hills covered with lush grass that provide fine pasture, plenty of fruit and all things in great abundance. After riding for six days, he reaches Sheberghan, a city rich with melons and game, then moves to Balkh, a large city ruined by Tartars but once boasting palaces.	马可·波罗描述了从城堡出发，穿过肥沃的平原和山谷，到达以甜瓜和猎物闻名的谢贝尔汉城，随后前往巴尔赫，一座被鞑靼人破坏的古城，曾拥有大理石宫殿。	Marco Polo describes the journey from a castle through fertile plains and valleys to Sheberghan, known for its melons and game, then to Balkh, a city ravaged by Tartars that once had marble palaces and historical significance.	["Marco Polo"]	[]
14	\N	Khubilai Khan	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-007.json	Chapter 3: Khubilai Khan	["Yuan Dynasty", "Mongol Empire", "Imperial Court", "Paper Currency", "Buddhism", "Christianity", "Islam"]	\N	The text describes the late 13th century (1250s-1290s) during the Yuan Dynasty, a period of Mongol rule over China and vast Eurasian territories.	Kublai Khan, the founder of the Yuan Dynasty, consolidated power through military conquest and administrative reforms, dealing with internal rebellions (Nayan) and external rivals (Qaidu). The narrative highlights his centralized authority and complex bureaucratic system.	The chapter portrays a pluralistic religious environment where Kublai Khan is portrayed as respectful of multiple faiths (Christianity, Islam, Buddhism) while holding personal inclinations towards Christianity and practical policies towards others. The text mentions specific religious tensions and the Khan's pragmatic approach.	The narrative depicts a highly stratified society with elaborate court rituals, a vast postal system, state-controlled economy (paper currency), and systematic provisions for the poor. It also describes urban planning, law enforcement, and social customs in the capital cities.	1275-1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "The text describes the late 13th century (1250s-1290s) during the Yuan Dynasty, a period of Mongol rule over China and vast Eurasian territories.", "political_context": "Kublai Khan, the founder of the Yuan Dynasty, consolidated power through military conquest and administrative reforms, dealing with internal rebellions (Nayan) and external rivals (Qaidu). The narrative highlights his centralized authority and complex bureaucratic system.", "religious_context": "The chapter portrays a pluralistic religious environment where Kublai Khan is portrayed as respectful of multiple faiths (Christianity, Islam, Buddhism) while holding personal inclinations towards Christianity and practical policies towards others. The text mentions specific religious tensions and the Khan's pragmatic approach.", "social_environment": "The narrative depicts a highly stratified society with elaborate court rituals, a vast postal system, state-controlled economy (paper currency), and systematic provisions for the poor. It also describes urban planning, law enforcement, and social customs in the capital cities.", "credibility_score": 0.8, "notes": "The account is generally reliable as a historical record of Mongol practices and Kublai Khan's reign, though it reflects the perspective of a European traveler (Marco Polo) and may contain exaggerations or second-hand information. The detailed descriptions of administrative systems, paper currency, and court protocols align with other historical records."}	null	At this point in our book I want to begin telling you about all the tremendous achievements and astonishing deeds of the reigning Great Khan, whose name is Khubilai Khan. In our language Khan means ‘Great Lord of Lords’, and indeed his right to this title is beyond doubt.	At this point in our book I want to begin telling you about all the tremendous achievements and astonishing deeds of the reigning Great Khan, whose name is Khubilai Khan. In our language Khan means ‘Great Lord of Lords’, and indeed his right to this title is beyond doubt.	本章详细描述了忽必烈大汗的生平、功绩与宫廷生活。内容包括他平定乃颜叛乱的过程、他的外貌与家庭、宫廷的宏伟建筑（包括汗八里城和大都城）、他的行政体系、邮驿系统、宗教政策、慈善事业、以及他的狩猎与娱乐活动。文中也解释了纸币的发行与使用。	This chapter provides a detailed account of the life, achievements, and court life of Kublai Khan. It covers his victory over the rebel Nayan, his physical appearance and family, the magnificent architecture of his palaces and cities (Khanbaliq and Daidu), his administrative and postal systems, his religious policies, his charitable works, and his hunting and entertainment activities. The chapter also explains the issuance and use of paper currency.	["Khubilai Khan", "Genghis Khan", "Nayan", "Qaidu", "Tem\\u00fcr", "Genghis (son)", "Ahmad (Bailo)", "Qianhu", "Wanhu", "Kogatai", "Bayan", "Mingan", "Messer Niccol\\u00f2", "Messer Maffeo"]	["1256-01-01", "1286-01-01", "1298-01-01"]
15	\N	From Beijing to Bengal	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-008.json	Chapter 4	["Yuan dynasty", "Mongol Empire", "Silk Road", "Chinese provinces", "Imperial envoy"]	\N	13th century, Yuan dynasty under Kublai Khan, a period of Mongol control over China and extensive trade networks.	Kublai Khan's empire is centralized and expansive, with his envoys traveling through well-administered provinces.	Buddhist and Taoist practices (idolaters) are predominant, with Nestorian Christians and Saracens present as minorities.	Prosperous cities with active trade, crafts, and agriculture; imperial control ensures order and infrastructure like bridges and roads.	1275-1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th century, Yuan dynasty under Kublai Khan, a period of Mongol control over China and extensive trade networks.", "political_context": "Kublai Khan's empire is centralized and expansive, with his envoys traveling through well-administered provinces.", "religious_context": "Buddhist and Taoist practices (idolaters) are predominant, with Nestorian Christians and Saracens present as minorities.", "social_environment": "Prosperous cities with active trade, crafts, and agriculture; imperial control ensures order and infrastructure like bridges and roads.", "credibility_score": 0.8, "notes": "Marco Polo's account provides detailed geographical and cultural observations, though some descriptions may be exaggerated or influenced by hearsay. The narrative is consistent with historical records of Yuan dynasty China."}	null	Now you should know that the emperor sent Messer Marco himself as an envoy into the west. So he set out from Khanbaliq and headed west on a journey of no less than four months; and we will tell you everything he saw along the way, both going and coming.	Now you should know that the emperor sent Messer Marco himself as an envoy into the west. So he set out from Khanbaliq and headed west on a journey of no less than four months; and we will tell you everything he saw along the way, both going and coming.	马可·波罗作为忽必烈汗的使者从汗八里（北京）出发西行，详细描述了沿途经过的宏伟石桥、城市（如涿州、太原府）以及地方特产（如丝绸、葡萄酒）。这段旅程展现了元代中国的繁荣景象和帝国对地方的控制。	Marco Polo, as an envoy of Kublai Khan, departs from Khanbaliq (Beijing) on a westward journey, describing a magnificent stone bridge, cities like Zhuozhou and Taiyuanfu, and local products like silk and wine. The narrative highlights the prosperity of Yuan dynasty China and imperial control over its provinces.	["Marco Polo", "Kublai Khan"]	["1275-1291"]
16	\N	Five: From Beijing to Quanzhou	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-009.json	Chapter 5	["Mongol Empire", "Yuan Dynasty", "trade routes", "silk production", "cultural exchange"]	\N	13th century during the Yuan Dynasty under Kublai Khan, after the Mongol conquest of Song Dynasty China.	The Mongol Empire rules from Beijing (Khanbaliq), with southern China (Manzi) recently conquered and divided into nine kingdoms under appointed kings, while maintaining large garrison armies.	Predominantly idolatry (likely Buddhism/Daoism) with Nestorian Christian communities present. The Great Khan's court practices religious tolerance. Detailed descriptions of idol worship practices.	A highly developed urban society with extensive trade, paper money, specialized guilds, and sophisticated water-based transportation. Strict social customs around female chastity and elaborate funeral rites are noted.	1275-1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th century during the Yuan Dynasty under Kublai Khan, after the Mongol conquest of Song Dynasty China.", "political_context": "The Mongol Empire rules from Beijing (Khanbaliq), with southern China (Manzi) recently conquered and divided into nine kingdoms under appointed kings, while maintaining large garrison armies.", "religious_context": "Predominantly idolatry (likely Buddhism/Daoism) with Nestorian Christian communities present. The Great Khan's court practices religious tolerance. Detailed descriptions of idol worship practices.", "social_environment": "A highly developed urban society with extensive trade, paper money, specialized guilds, and sophisticated water-based transportation. Strict social customs around female chastity and elaborate funeral rites are noted.", "credibility_score": 0.85, "notes": "Marco Polo's account is detailed and often corroborated by archaeological and historical records of Yuan Dynasty China. While some descriptions may be exaggerated (e.g., the size of the fish, specific population numbers), the overall depiction of major cities like Hangzhou (Xingzai) aligns with Chinese sources. The inclusion of personal experiences (governing Yangzhou, building trebuchets) adds to its credibility as a firsthand account, though some details are debated by historians."}	null	When the traveller leaves Zhuozhou, he rides southward for four days past many cities and villages. The people thrive on trade and industry. They are idolaters and use the paper money of the Great Khan their lord. At the end of these four days he comes to the city of Hejianfu, which lies towards the south and is in the province of Cathay.	When the traveller leaves Zhuozhou, he rides southward for four days past many cities and villages. The people thrive on trade and industry. They are idolaters and use the paper money of the Great Khan their lord. At the end of these four days he comes to the city of Hejianfu, which lies towards the south and is in the province of Cathay.	本章记述了马可·波罗从北京到泉州的旅程，途经河北、河南、安徽、江苏、浙江、福建等地，描述了众多城市的风貌、物产、贸易及风俗。他特别详细记载了杭州（即行在）的繁华景象、宫殿遗址、人口、税收及市民生活习俗。旅程最终到达重要港口泉州（刺桐），并提及了从泉州到印度的航程。	This chapter details Marco Polo's journey from Beijing to Quanzhou, passing through numerous cities in Cathay and Manzi. It describes the geography, trade, industries, and customs of each location, with a lengthy and elaborate account of the former capital of Manzi, Xingzai (likely Hangzhou), detailing its size, canals, markets, and social life. The journey concludes at the major port of Zayton (Quanzhou), described as one of the world's busiest, before transitioning to the next chapter about India.	["Khubilai Khan", "Marco Polo", "Niccol\\u00f2 Polo", "Maffeo Polo", "Bayan Chingsang", "Litan Sangon", "Facfur", "Mar Sergius"]	["1272-01-01", "1278-01-01", "1268-01-01"]
17	\N	From China to India	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-010.json	Chapter 6	["13th century", "Mongol Empire", "maritime trade", "Indian Ocean", "exploration"]	\N	13th-century Mongol Empire era with extensive trade networks connecting China, India, and Southeast Asia	Khubilai Khan's Yuan Dynasty ruled China, with vassal relationships extending to Southeast Asian kingdoms	Buddhist and Hindu idolatry described alongside Islamic influence from Saracen merchants	Maritime trade-based economies with complex shipbuilding traditions and diverse cultural interactions	1275 - 1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th-century Mongol Empire era with extensive trade networks connecting China, India, and Southeast Asia", "political_context": "Khubilai Khan's Yuan Dynasty ruled China, with vassal relationships extending to Southeast Asian kingdoms", "religious_context": "Buddhist and Hindu idolatry described alongside Islamic influence from Saracen merchants", "social_environment": "Maritime trade-based economies with complex shipbuilding traditions and diverse cultural interactions", "credibility_score": 0.75, "notes": "Detailed descriptions of ship construction suggest eyewitness knowledge, though some geographical and cultural details may be embellished or secondhand"}	null	Now since we have told you about so many regions of the mainland as you have heard, we will leave all that behind and make our way into India; and we will relate all the wonders that are found there, beginning first of all with the ships in which the merchants travel to and from India.	Now since we have told you about so many regions of the mainland as you have heard, we will leave all that behind and make our way into India; and we will relate all the wonders that are found there, beginning first of all with the ships in which the merchants travel to and from India.	马可·波罗结束了对大陆地区的描述，转而开始讲述印度的故事，首先详细描述了往来印度的商船构造、航行实验和沿途岛屿。	Marco Polo concludes his description of mainland regions and transitions to India, starting with a detailed account of merchant ships sailing to and from India, their construction, and voyage omens.	[]	[]
18	\N	Maabar: Greater India	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-011.json	SEVEN India	["13th century", "India", "trade", "customs", "pearl fishing"]	\N	13th century during the Mongol Empire's influence, with trade routes connecting Asia and Europe.	Local kingdoms in India ruled by kings and queens, paying no tribute to external powers.	Dominant idolatry with influences from Hinduism and Buddhism, plus early Christian presence.	Society based on trade, with strict customs around nudity, justice, and daily rituals.	1290-1292	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th century during the Mongol Empire's influence, with trade routes connecting Asia and Europe.", "political_context": "Local kingdoms in India ruled by kings and queens, paying no tribute to external powers.", "religious_context": "Dominant idolatry with influences from Hinduism and Buddhism, plus early Christian presence.", "social_environment": "Society based on trade, with strict customs around nudity, justice, and daily rituals.", "credibility_score": 0.7, "notes": "Marco Polo's account is generally reliable but may include exaggerations or second-hand information typical of travel journals of the era."}	null	When the traveller leaves the island of Ceylon and sails westward for about sixty miles he comes to the great province of Maabar, which is called Greater India. It is indeed the best of the Indies and forms part of the mainland.	When the traveller leaves the island of Ceylon and sails westward for about sixty miles he comes to the great province of Maabar, which is called Greater India. It is indeed the best of the Indies and forms part of the mainland.	马可·波罗描述了印度最富庶的省份马巴尔，以采珠业和国王佩戴珍贵宝石闻名。他详细介绍了当地裸体习俗、偶像崇拜和严厉的司法制度。	Marco Polo describes Maabar, the richest province in India, renowned for pearl fishing and its king adorned with precious gems. He details customs such as nudity, idol worship, and harsh justice systems.	["Sundara Pandya Devar"]	[]
19	\N	The Arabian Sea	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-012.json	Chapter 8: The Arabian Sea	["Christianity", "Arabian Sea", "social customs", "ambergris", "fishing"]	\N	13th century travel narrative during the Mongol Empire period	Fragmented Islamic and Christian territories in the Indian Ocean region	Presence of Christian communities following Old Testament customs in the Indian Ocean	Describes unique gender-segregated social structures and economic activities	1275-1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th century travel narrative during the Mongol Empire period", "political_context": "Fragmented Islamic and Christian territories in the Indian Ocean region", "religious_context": "Presence of Christian communities following Old Testament customs in the Indian Ocean", "social_environment": "Describes unique gender-segregated social structures and economic activities", "credibility_score": 0.7, "notes": "Marco Polo's account includes detailed but fantastical descriptions of remote islands; some details about Christian communities may be exaggerated or based on second-hand information."}	null	Male Island lies out in the open sea a good 500 miles south of Kesh-Makran. Its inhabitants are baptized Christians and follow the faith and customs of the Old Testament... The men of Male Island go over to Female Island and stay there for three months, namely March, April and May.	Male Island lies out in the open sea a good 500 miles south of Kesh-Makran. Its inhabitants are baptized Christians and follow the faith and customs of the Old Testament... The men of Male Island go over to Female Island and stay there for three months, namely March, April and May.	本段描述了马尔岛（Male Island）的独特社会结构，岛上居民为信奉旧约的基督徒。男性居民每年在3月至5月期间前往女性岛（Female Island）与妻子团聚，其余九个月则在马尔岛谋生。马尔岛盛产高品质龙涎香，居民以稻米、牛奶和肉类为食，渔业发达，鱼获丰富。	This passage describes the unique social structure of Male Island, whose inhabitants are baptized Christians following the Old Testament. The men of Male Island travel to Female Island for three months (March, April, and May) to be with their wives, spending the other nine months earning a livelihood on Male Island. The island produces high-quality ambergris, its people live on rice, milk, and meat, and it has a prosperous fishing industry.	[]	[]
20	\N	Northern Regions and Tartar Wars	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-013.json	Chapter 9	["Mongol Empire", "succession wars", "Central Asia", "Ilkhanate", "military campaigns"]	\N	13th-century Mongol Empire, during the period of khanate fragmentation and civil wars following the death of Möngke Khan.	Fragmentation of the Mongol Empire into competing khanates (Yuan, Chagatai, Golden Horde, Ilkhanate), with constant warfare over territory and legitimacy.	Mix of Tengriism, Christianity (Nestorian), and Islam; religious shifts (e.g., Ahmad Sultan becoming a Saracen) used to justify political claims.	Nomadic warrior societies with complex lineages (Genghisid), where military prowess and loyalty of barons determined political power.	1266 - 1294	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th-century Mongol Empire, during the period of khanate fragmentation and civil wars following the death of M\\u00f6ngke Khan.", "political_context": "Fragmentation of the Mongol Empire into competing khanates (Yuan, Chagatai, Golden Horde, Ilkhanate), with constant warfare over territory and legitimacy.", "religious_context": "Mix of Tengriism, Christianity (Nestorian), and Islam; religious shifts (e.g., Ahmad Sultan becoming a Saracen) used to justify political claims.", "social_environment": "Nomadic warrior societies with complex lineages (Genghisid), where military prowess and loyalty of barons determined political power.", "credibility_score": 0.8, "notes": "Detailed narrative with specific dates and military tactics, likely based on accounts from merchants and diplomats. Some exaggeration in troop numbers (e.g., 100,000, 600,000 horsemen) is typical of medieval chronicles. Personal anecdotes (like Aiyurug's wrestling) may be embellished but reflect cultural practices."}	null	There is a king in Turkestan called Qaidu who is a nephew of the Great Khan’s... Now it happened in the year 1266 from the incarnation of Christ this King Qaidu and his cousins... mustered an immense force and attacked two of the Great Khan’s barons... In the year 1280 from the incarnation of Christ that a rich king’s son... arrived here... Now you should know that when Arghun began his rule it was the year 1286 from the incarnation of Jesus Christ. Ahmad Sultan held the lordship for two years, and Arghun reigned for six years.	This excerpt details the political conflicts and military campaigns involving Qaidu, the wars of succession among the Mongol rulers in the Levant following Abagha's death, and the reigns of Arghun, Ahmad Sultan, Gaykhatu, Baidu, and Ghazan, with dates given in the Christian era.	本节讲述了突厥斯坦的海都汗与元世祖忽必烈之间的长期战争，以及由此引发的多次血腥战役，包括海都与其堂兄弟之间、以及其女儿的比武招亲故事。随后详细描述了阿巴哈（Abagha）去世后，其子阿鲁浑（Arghun）与其叔父艾哈迈德（Ahmad）之间争夺伊尔汗国统治权的战争，最终阿鲁浑在部下帮助下复位，并在其子合赞（Ghazan）继位前经历多次政权更迭。	This section describes the protracted war between Qaidu Khan of Turkestan and Kublai Khan, including several fierce battles, as well as an anecdote about Qaidu's daughter's wrestling contests for suitors. It then provides a detailed account of the succession struggle in the Levant after the death of Abagha, focusing on the conflict between his son Arghun and his uncle Ahmad Sultan, Arghun's capture and subsequent rescue, his eventual rule, and the succession through Gaykhatu and Baidu to Ghazan.	["Qaidu", "Kublai Khan (Great Khan)", "Chagatai", "Yesudar", "Chibai", "Chiban", "Nomuqan", "George (grandson of Prester John)", "Aiyurug (Qaidu's daughter)", "Abagha", "Arghun", "Ahmad Sultan", "Baraq", "Sultan (malik)", "Buqa", "Elchidei", "Toghan", "Tegene", "Taghachar", "Ulaatai", "Samaghar", "Ghazan", "Gaykhatu", "Baidu", "Hulegu", "Genghis Khan", "Prester John"]	["1266-01-01", "1280-01-01", "1286-01-01", "1294-01-01"]
21	\N	Invisible Cities	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-016.json	BOOKS INSPIRED BY THE TRAVELS	["literature", "fiction", "imaginary cities", "Venice", "Kublai Khan"]	\N	Modern literary work inspired by historical travels.	No specific political context described in this excerpt.	Not relevant.	Literary and imaginative interpretation of historical travel narratives.	1972	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "Modern literary work inspired by historical travels.", "political_context": "No specific political context described in this excerpt.", "religious_context": "Not relevant.", "social_environment": "Literary and imaginative interpretation of historical travel narratives.", "credibility_score": 0.0, "notes": "This is a fictional literary work, not a primary historical source."}	null	Marco Polo describes to Khubilai Khan various imaginary cities he visited – all in some way versions of his hometown, Venice.	Marco Polo describes to Khubilai Khan various imaginary cities he visited – all in some way versions of his hometown, Venice.	伊塔洛·卡尔维诺的小说《看不见的城市》描述了马可·波罗向忽必烈汗讲述他所造访的各种虚构城市，这些城市在某种程度上都是他的家乡威尼斯的变体。	Italo Calvino's novel 'Invisible Cities' describes Marco Polo telling Kublai Khan about various imaginary cities he visited, all of which are in some way versions of his hometown, Venice.	["Italo Calvino", "Marco Polo", "Khubilai Khan"]	[]
22	\N	Prologue	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-018.json	Prologue	["travel narrative", "presentation", "slave", "court", "preparation"]	\N	13th-century travel narrative	Likely within the context of Mongol or European diplomacy	\N	Feudal or imperial court customs	1260-1295	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th-century travel narrative", "political_context": "Likely within the context of Mongol or European diplomacy", "religious_context": null, "social_environment": "Feudal or imperial court customs", "credibility_score": 0.7, "notes": "The excerpt is fragmentary and symbolic, possibly part of a larger anecdote about diplomacy or tribute."}	null	I have brought him … as your slave. And he held him … everyone at court. And when everything was prepared … everything that had happened to them.	The speaker presents someone as a slave, the recipient embraces him, and preparations are made to recount all that happened.	这段文字描述了一个人被作为奴隶献给另一个人的场景，接收者拥抱了他，并在一切准备就绪后，讲述了他们所经历的一切。这可能是对旅途中某个重要时刻的概括性叙述。	This passage describes a scene where someone is presented as a slave to another person, who embraces him. With everything prepared, the story of all that happened to them is then told, possibly summarizing a key moment from a journey.	[]	[]
23	\N	Chapter 2	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-019.json	Chapter 2	["Mongol Empire", "trade routes", "extreme climate", "travel", "Central Asia"]	\N	13th-century travel during the Mongol Empire's peak, a period of extensive trade and cultural exchange along the Silk Road.	The Mongol Empire facilitated relative safety and mobility for merchants across vast territories, though regional conflicts and harsh conditions persisted.	The text mentions heretics, indicating religious diversity and conflict in the regions traversed.	Travelers faced extreme environmental challenges, with local customs adapting to provide relief, such as using latticework for shade.	1271-1295	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th-century travel during the Mongol Empire's peak, a period of extensive trade and cultural exchange along the Silk Road.", "political_context": "The Mongol Empire facilitated relative safety and mobility for merchants across vast territories, though regional conflicts and harsh conditions persisted.", "religious_context": "The text mentions heretics, indicating religious diversity and conflict in the regions traversed.", "social_environment": "Travelers faced extreme environmental challenges, with local customs adapting to provide relief, such as using latticework for shade.", "credibility_score": 0.8, "notes": "The account is based on Marco Polo's personal experiences and observations, though some details may be embellished or influenced by contemporary accounts."}	null	Sometimes they rode out towards Rudbar. all the merchants who come they let them go. Here they build latticework to ward off the sun. to prove just how hot and throw them in. And since they are dying any day you name. the traveller reaches themselves and their beasts.	Sometimes they rode out towards Rudbar. All the merchants who come, they let them go. Here they build latticework to ward off the sun. To prove just how hot, and throw them in. And since they are dying, any day you name. The traveller reaches themselves and their beasts.	章节描述了马可·波罗旅途中的一些见闻，包括当地的炎热气候、商人的活动以及地形特征。文中提到了人们建造格子结构以遮阳，以及旅行者如何在极端环境中保护自己和牲畜。	The chapter describes some of Marco Polo's observations during his travels, including the local hot climate, merchant activities, and terrain features. The text mentions the building of latticework to shade from the sun and how travelers protect themselves and their beasts in extreme conditions.	["Messer Marco"]	["1271-01-01", "1295-12-31"]
24	\N	The Road to Cathay	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-020.json	Chapter 2	["Turks", "Central Asia", "nomads"]	\N	13th-century Mongol Empire and Silk Road travel	Mongol dominance in Central Asia	N/A	Nomadic and settled Turkic communities	1260-1295	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th-century Mongol Empire and Silk Road travel", "political_context": "Mongol dominance in Central Asia", "religious_context": "N/A", "social_environment": "Nomadic and settled Turkic communities", "credibility_score": 0.7, "notes": "Fragmentary text; likely part of a larger description of Turkic peoples."}	null	For this reason the Turks who are in that region... straying off the path.	For this reason the Turks who are in that region... straying off the path.	文本提及该地区的突厥人，但未提供具体叙述。	The text mentions the Turks in the region but does not provide a specific narrative.	[]	[]
25	\N	CHAPTER 3	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-021.json	CHAPTER 3	["Yuan dynasty", "Mongol Empire", "palace architecture", "court ceremonies", "medieval China"]	\N	Late 13th century, Mongol-led Yuan Dynasty in China.	Khubilai Khan rules a vast empire from Daidu (Beijing).	Buddhist and shamanistic practices are observed in court rituals.	Elaborate court life with strict hierarchies and ceremonial duties.	1275-1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "Late 13th century, Mongol-led Yuan Dynasty in China.", "political_context": "Khubilai Khan rules a vast empire from Daidu (Beijing).", "religious_context": "Buddhist and shamanistic practices are observed in court rituals.", "social_environment": "Elaborate court life with strict hierarchies and ceremonial duties.", "credibility_score": 0.8, "notes": "Marco Polo's firsthand account of the Yuan court, likely embellished but based on direct observation."}	null	It stands on beautiful pillars... holding up the ceiling. ... and sweet ... this careful scrutiny	It stands on beautiful pillars... holding up the ceiling. ... and sweet ... this careful scrutiny	此段落描述了宫殿的宏伟建筑与内部装饰，包括支撑天花板的美丽柱子和精细的工艺。同时提及了宫廷中的一些仪式或观察活动。	This passage describes the magnificent architecture and interior decoration of the palace, including beautiful pillars supporting the ceiling and intricate craftsmanship. It also mentions some rituals or observations within the court.	[]	[]
26	\N	CHAPTER 5	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-022.json	Chapter 5	["Mongol Empire", "Yuan Dynasty", "trade", "urban life", "religious diversity"]	\N	The text describes the Yuan Dynasty (1271–1368), a period of Mongol rule in China.	The Mongol Empire under Kublai Khan was at its height, controlling a vast territory and promoting trade along the Silk Road.	The narrative mentions a mix of religions, including Christianity, Buddhism (idols), and local practices, reflecting the pluralistic nature of Mongol society.	The description highlights a bustling urban center with extensive infrastructure, diverse population, and active trade.	1275 - 1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "The text describes the Yuan Dynasty (1271\\u20131368), a period of Mongol rule in China.", "political_context": "The Mongol Empire under Kublai Khan was at its height, controlling a vast territory and promoting trade along the Silk Road.", "religious_context": "The narrative mentions a mix of religions, including Christianity, Buddhism (idols), and local practices, reflecting the pluralistic nature of Mongol society.", "social_environment": "The description highlights a bustling urban center with extensive infrastructure, diverse population, and active trade.", "credibility_score": 0.8, "notes": "The account is generally reliable for its time, though details may be exaggerated or influenced by limited understanding. It provides valuable firsthand observations of Mongol-era Beijing."}	null	There are also some Christians … church in the city. Through the midst … city of Khanbaliq. for they have extended … manmade waterways. no more than four fingers deep. You should also be aware … or paid homage to them.	There are also some Christians in the city with a church. Through the midst of the city flows a great river. They have extended it by manmade waterways, some no more than four fingers deep. You should also be aware that many have seen or paid homage to them.	马可·波罗描述了汗八里（北京）的城市状况，包括城中的基督徒、流经城市的河流及其人工水道，以及各种居民和宗教信仰的状况。他还提到了当地的一些习俗和资源。	Marco Polo describes the state of Khanbaliq (Beijing), including the Christians in the city, the great river flowing through the city and its artificial waterways, the various inhabitants, and religious practices. He also mentions local customs and resources.	["Great Khan"]	[]
27	\N	The Travels	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-023.json	Prologue	["trade", "customs", "transport"]	\N	Late 13th century, during the Mongol Empire's height.	The Mongol Empire facilitated trans-Eurasian travel and trade.	Observations of various religious practices among diverse populations.	Cultural exchange and trade practices in the Indian Ocean region.	1275 - 1291	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "Late 13th century, during the Mongol Empire's height.", "political_context": "The Mongol Empire facilitated trans-Eurasian travel and trade.", "religious_context": "Observations of various religious practices among diverse populations.", "social_environment": "Cultural exchange and trade practices in the Indian Ocean region.", "credibility_score": 0.7, "notes": "Description appears to be of local customs in a trade context, consistent with Marco Polo's observational style."}	null	and they bring them … tied to their bodies.	and they bring them … tied to their bodies.	这一段描述了当地人如何将物品（可能是珍珠或贝壳）捆绑在身上进行运输或交易的习俗。	This passage describes how locals carry items, possibly pearls or shells, by tying them to their bodies for transport or trade.	[]	[]
28	\N	Prologue 1	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-024.json	PROLOGUE 1	["Mongol Empire", "Silk Road", "13th century", "medieval travel", "historical chronology"]	\N	13th century during the Mongol Empire's expansion and fragmentation	Mongol rule under Kublai Khan, with civil wars and trade diplomacy	Christianity, Islam, and Buddhism interactions along trade routes	Trade and cultural exchanges via the Silk Road, with diplomatic missions	1250-1295	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th century during the Mongol Empire's expansion and fragmentation", "political_context": "Mongol rule under Kublai Khan, with civil wars and trade diplomacy", "religious_context": "Christianity, Islam, and Buddhism interactions along trade routes", "social_environment": "Trade and cultural exchanges via the Silk Road, with diplomatic missions", "credibility_score": 0.7, "notes": "Annotations provide historical context but may include conjectures and variations from different manuscript sources."}	null	This sentence and the comment about Marco’s decision to make profitable use of his time in prison are from Z, which, however, does not mention Rustichello. R adds that the text as it stands is nothing compared to the ‘many and almost infinite things’ that Marco would have been able to recount.	This sentence and the comment about Marco’s decision to make profitable use of his time in prison are from Z, which, however, does not mention Rustichello. R adds that the text as it stands is nothing compared to the ‘many and almost infinite things’ that Marco would have been able to recount.	这篇序言为马可·波罗的旅行提供了历史背景和注释，涵盖了从1250年到1295年的事件，包括蒙古帝国的兴衰和丝绸之路的贸易路线。	This prologue provides historical context and annotations for Marco Polo's travels, covering events from 1250 to 1295, including the Mongol Empire's rise and fall and Silk Road trade routes.	["Marco Polo", "Kublai Khan", "Niccol\\u00f2 Polo", "Maffeo Polo", "Baldwin II", "Berke Khan", "Hulegu", "Baraq", "Arghun", "Ghazan"]	["1250-01-01", "1260-01-01", "1269-01-01", "1294-01-01"]
29	\N	The Road from the Assassins' Country to Kashgar	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-026.json	TWO 1-4	["Silk Road", "medieval travel", "Afghanistan", "Central Asia", "geography"]	\N	13th-century travel along the Silk Road during the Mongol Empire.	Regions were often under Mongol or local Turkic/Persian rule.	Areas were predominantly Muslim, with Hindu and Buddhist influences in Kashmir and beyond.	Trade routes connecting the Mediterranean to China.	1275-01-01 - 1275-12-31	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "13th-century travel along the Silk Road during the Mongol Empire.", "political_context": "Regions were often under Mongol or local Turkic/Persian rule.", "religious_context": "Areas were predominantly Muslim, with Hindu and Buddhist influences in Kashmir and beyond.", "social_environment": "Trade routes connecting the Mediterranean to China.", "credibility_score": 0.9, "notes": "This entry combines Marco Polo's narrative route with the translator's geographical identifications. The route is historically plausible for the 13th century."}	null	When the traveller leaves this castle, the following itinerary leads eastwards through modern-day northern Afghanistan, taking in Sheberghan, Balkh, Taleqan, Iskashim, Badakhshan and Wakhan, with a digression to Pashai and Kashmir. L says that twelve days further on are the regions where pepper grows, near the Kingdom of Braaman.	When the traveller leaves this castle, the following itinerary leads eastwards through modern-day northern Afghanistan, taking in Sheberghan, Balkh, Taleqan, Iskashim, Badakhshan and Wakhan, with a digression to Pashai and Kashmir. L says that twelve days further on are the regions where pepper grows, near the Kingdom of Braaman.	这段文字描述了旅行者离开城堡后向东穿越今阿富汗北部的路线，途经谢伯尔干、巴尔赫、塔勒坎、伊斯卡希姆、巴达赫尚和瓦罕，并有前往帕沙伊和克什米尔的支线。注释者L提到再走十二天就是香料产区和婆罗门王国。	The text describes the traveler's eastward route from a castle through modern northern Afghanistan, including Sheberghan, Balkh, Taleqan, Iskashim, Badakhshan, and Wakhan, with a digression to Pashai and Kashmir. Note-taker L states that twelve days further are the pepper-growing regions near the Kingdom of Braaman.	[]	[]
30	\N	The Arabian Sea	pipeline/output/the-travels-of-marco-polo/the-travels-of-marco-polo-en-033.json	Chapter Eight: The Arabian Sea	["Indian Ocean trade", "East Africa", "Arabian geography", "medieval hearsay", "Nestorian notes"]	\N	Late 13th-century European exploration and trade routes	Mongol-era connections to the Indian Ocean	Mention of Nestorian Christianity in prior note	Maritime trade and cultural exchange along East African coast	1286-1287	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	{"era_context": "Late 13th-century European exploration and trade routes", "political_context": "Mongol-era connections to the Indian Ocean", "religious_context": "Mention of Nestorian Christianity in prior note", "social_environment": "Maritime trade and cultural exchange along East African coast", "credibility_score": 0.5, "notes": "Marco's descriptions are based on secondhand reports, containing geographical errors. Translator notes clarify misunderstandings."}	null	Madagascar: Spelt madeigascar or similar in F and many versions but mogdaxo in Z, which (along with much of the description) seems to indicate Mogadishu in Somalia. Marco’s great ‘island’ may in fact be the Horn of Africa, and the name of Madagascar itself may well derive from Marco’s error compounded by those of his copyists. Zanzibar: Again, this is probably not the island (which is vastly smaller than Marco says) but the large part of coastal East Africa known by the Arabs as Zanj. Marco almost certainly never visited East Africa and was relying on hearsay. camel meat: Z says the inhabitants eat many other kinds of flesh as well, though camel meat is their favourite because	Madagascar: Spelt madeigascar or similar in F and many versions but mogdaxo in Z, which (along with much of the description) seems to indicate Mogadishu in Somalia. Marco’s great ‘island’ may in fact be the Horn of Africa, and the name of Madagascar itself may well derive from Marco’s error compounded by those of his copyists. Zanzibar: Again, this is probably not the island (which is vastly smaller than Marco says) but the large part of coastal East Africa known by the Arabs as Zanj. Marco almost certainly never visited East Africa and was relying on hearsay. camel meat: Z says the inhabitants eat many other kinds of flesh as well, though camel meat is their favourite because	马可·波罗描述了‘马达加斯加’（可能指索马里摩加迪沙或非洲之角）和‘桑给巴尔’（可能指阿拉伯人称为‘赞吉’的东非沿海地区），并记载当地居民喜食骆驼肉。译者指出马可·波罗可能依赖传闻，从未亲访东非。	Marco Polo describes 'Madagascar' (possibly Mogadishu or the Horn of Africa) and 'Zanzibar' (likely the Arab-named 'Zanj' coastal East Africa), noting the inhabitants' fondness for camel meat. The translator suggests Marco relied on hearsay and never visited East Africa.	["Marco Polo"]	["1286-01-01", "1287-12-31"]
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (id, name, modern_name, ancient_name, latitude, longitude, location_type, ancient_region, one_line_summary, location_rationale, academic_disputes, credibility_notes, today_remains, created_at, updated_at, geo_certainty, certainty_note) FROM stdin;
1	Índia	India	Índia	20.5937	78.9629	region	\N	A major region of the author's travels in the East.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
2	Etiópia	Ethiopia	Etiópia	9.145	40.4897	region	\N	An ancient kingdom in East Africa visited by the author.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
3	Arábia Feliz	Southern Arabia (Yemen)	Arábia Feliz	15.5527	48.5164	region	\N	Historical name for the fertile southern part of the Arabian Peninsula.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
4	China	China	China	35.8617	104.1954	region	\N	A major empire in East Asia, a key destination in the narrative.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
5	Tartária	Central/Northern Asia	Tartária	45	90	region	\N	Historical term for the vast regions of Central and Northern Asia.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
6	M. açaçar	Malacca	Malaça	2.1896	102.2501	city	\N	A strategic port city in the Malay Peninsula.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
7	Samatra	Sumatra	Samatra	-0.5897	101.3431	island	\N	A large island in the Indonesian archipelago.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
8	Liampó	Ningbo	Liampó	29.8683	121.544	port	\N	A major port city in China where António de Faria intended to winter.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
9	Malaca	Malacca	Malaca	2.1896	102.2501	port	\N	A key trading port in the Malay Peninsula, part of the Portuguese Estado da Índia.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
10	Nouday	Ningbo	Nouday	29.8683	121.544	city	\N	A Chinese coastal city sacked and burned by António de Faria's expedition.	\N	\N	\N	\N	2026-05-05 21:37:09.940973+08	2026-05-05 21:37:09.940973+08	\N	\N
11	Venice	Venice	Venice	45.4408	12.3155	city	\N	Marco Polo's birthplace and home city in Italy	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
12	Black Sea	Black Sea	Black Sea	43	35	sea	\N	Sea crossed by Polo's father and uncle on business venture	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
13	Beijing	Beijing	Khanbaliq/Dadu	39.9042	116.4074	city	\N	Capital of Mongol Empire under Khubilai Khan, base for Marco's missions	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
14	Mongol Empire	Central Asia, China, Russia	Mongol Empire	46	100	region	\N	Vast empire spanning Asia and Eastern Europe during 13th-14th centuries	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
15	Genoa	Genoa	Genoa	44.4056	8.9463	city	\N	Rival maritime republic where Marco was imprisoned.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
16	Pisa	Pisa	Pisa	43.7228	10.4017	city	\N	Hometown of Rustichello of Pisa.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
17	Armenia	Armenia	Armenia	40.0691	45.0382	region	\N	Starting point of the journey described in the book.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
18	Sea of Japan	Sea of Japan	Sea of Japan	39	133	sea	\N	Eastern geographical limit mentioned.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
19	Sumatra	Sumatra	Sumatra	-0.5897	101.3431	island	\N	Spice forest location described.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
20	Zanzibar	Zanzibar	Zanzibar	-6.1659	39.2026	island	\N	Southern geographical limit mentioned.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
21	Ethiopia	Ethiopia	Ethiopia	9.145	40.4897	region	\N	Another far-reaching location mentioned.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
22	Constantinople	Istanbul	Constantinople	41.0082	28.9784	city	\N	Possible limit of Marco's travels according to skeptics.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
23	Crimea	Crimea	Crimea	44.9521	34.1024	region	\N	Another proposed limit of Marco's travels.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
24	Indian Ocean	Indian Ocean	Erythraean Sea	-10	70	other	\N	Major ocean used for trade routes between Rome, India, and the East.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
25	India	India	\N	20.5937	78.9629	region	\N	Source of spices and a key trade destination for Roman freighters.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
26	Central Asia	Central Asia	\N	40	60	region	\N	Region with caravan routes through which Roman gold flowed to pay for silk.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
27	Jerusalem	Jerusalem	\N	31.7683	35.2137	city	\N	Placed at the center of medieval Western Christian world maps.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
28	Garden of Eden	\N	Garden of Eden	0	0	other	\N	Biblical paradise placed at the top of medieval maps, corresponding to the Far East.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
29	Caucasus	Caucasus	\N	42	44	region	\N	Mountain range north of which the legendary lands of Gog and Magog were placed.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
30	River Nile	Nile River	River Nile	30.0444	31.2357	river	\N	Major river in Northeast Africa, referenced to describe the imagined extent of India.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
31	Ganges	Ganges River	Ganges	25.4358	81.8463	river	\N	Major river in India, featured in Alexander's legendary voyage.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
32	Lesser Armenia	Cilicia	Lesser Armenia	37	35.3213	region	\N	A kingdom on the coast, subject to the Tartars, known for trade and unhealthy climate.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
33	Ayas	Yumurtalık	Ayas	36.7619	35.7933	city	\N	A bustling coastal trade center where spices and goods from the interior are shipped.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
34	Turkey	Turkey	Anatolia	39	35	region	\N	Home to Turkmens, Armenians, and Greeks, famed for fine carpets and silk cloths.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
35	Greater Armenia	Eastern Anatolia	Greater Armenia	40.0691	43	region	\N	A large province with summer pastures for Tartars and the legendary Mountain of Noah's Ark.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
36	Erzincan	Erzincan	Erzincan	39.7525	39.5	city	\N	A city in Greater Armenia known for producing the finest buckram and having beautiful baths.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
37	Mountain of Noah's Ark	Mount Ararat	Mountain of Noah's Ark	39.702	44.2975	mountain	\N	A cubic-shaped, snow-capped mountain said to be where Noah's Ark rested.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
38	Georgia	Georgia	Georgia	42.3154	43.3569	region	\N	A Christian kingdom with a king named David Malik, subject to the Tartars and home to a monastery with miraculous fish.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
39	Sea of Ghel	Caspian Sea	Sea of Ghel or Baku	41	50	sea	\N	A large inland sea (lake) surrounded by mountains, containing islands settled by refugees.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
40	Sheberghan	Sheberghan	\N	36.65	65.75	city	\N	City rich in dried melons and game.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
41	Balkh	Balkh	Bactra	36.75	66.89	city	\N	Large city once noble, now ruined by Tartars, on Persia's frontier.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
42	Khanbaliq	Beijing	Khanbaliq / Dadu	39.9042	116.4074	city	\N	The capital city of Kublai Khan's Yuan Dynasty, also known as Daidu.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
43	Cathay	Northern China	Cathay	39.9042	116.4074	region	\N	The name for northern China under Mongol rule.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
44	Manchuria	Northeast China	Manchuria	43.8868	125.3245	region	\N	One of the provinces that submitted to Kublai Khan after Nayan's defeat.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
45	Korea	Korean Peninsula	Korea	36.5	127.75	region	\N	One of the provinces that submitted to Kublai Khan after Nayan's defeat.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
46	Shangdu	Xanadu	Shangdu / Xanadu	42.3553	116.2056	city	\N	The summer capital of Kublai Khan, where he spent part of the year.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
47	Onggirat	\N	Onggirat	48	115	region	\N	A province inhabited by the Onggirat people, from whom Kublai Khan selected concubines.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
48	Cachar Modun	\N	Cachar Modun	42.5	116.5	camp	\N	A location where Kublai Khan's hunting camp was pitched.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
49	Ocean Sea	Bohai Sea	Ocean Sea	38.5	121	sea	\N	The sea south of Khanbaliq where Kublai Khan went hawking.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
50	Pulisanghin	Yongding River	Pulisanghin	39.9	116	river	\N	A large river crossed by a magnificent stone bridge near Khanbaliq.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
51	Zhuozhou	Zhuozhou	Zhuozhou	39.48	115.97	city	\N	A city with idolaters' abbeys, known for trade, silk, and sendal fabrics.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
52	Taiyuanfu	Taiyuan	Taiyuanfu	37.8706	112.5489	city	\N	Capital of a kingdom in Cathay, supplying imperial armies and producing wine and silk.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
53	Hejianfu	Hejian	Hejianfu	38.445	116.084	city	\N	Large city in Cathay, known for silk production.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
54	Changlu	Changlu	Changlu	0	0	city	\N	City famous for its salt production.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
55	Jiangling	Jingzhou	Jiangling	30.3257	112.2384	city	\N	City on a major river with extensive trade.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
56	Dongpingfu	Dongping	Dongpingfu	35.9818	116.4513	city	\N	Former kingdom, now under the Great Khan.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
57	Xinzhou matou	Xinzhou	Xinzhou matou	0	0	city	\N	Wealthy trading city with a major river junction.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
58	Liucheng	Liuzhou	Liucheng	24.3263	109.412	city	\N	Capital of a province, known for jujubes.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
59	Pizhou	Pizhou	Pizhou	34.3234	118	city	\N	Gateway to the province of Manzi.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
60	Suqian	Suqian	Suqian	33.9621	118.2696	city	\N	Wealthy city amid fertile plains.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
61	Qara-Muren	Yellow River	Qara-Muren	0	0	river	\N	Major river, a mile wide, teeming with ships.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
62	Huai'anzhou	Huai'an	Huai'anzhou	33.5875	119.0213	city	\N	Large city at the entrance to Manzi, with salt trade.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
63	Huaiyin	Huaiyin	Huaiyin	0	0	city	\N	Small city opposite Huai'anzhou.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
64	Manzi	Southern China	Manzi	0	0	region	\N	Southern province conquered by the Great Khan.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
65	Xingzai	Hangzhou	Xingzai (City of Heaven)	30.2741	120.1551	city	\N	Capital of Manzi, described as the world's finest city.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
66	Baoying	Baoying	Baoying	33.2299	119.3085	city	\N	Beautiful city with Nestorian Christians.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
67	Gaoyou	Gaoyou	Gaoyou	32.786	119.447	city	\N	Large city abundant in fish and game.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
68	Taizhou	Taizhou (Jiangsu)	Taizhou	32.484	119.923	city	\N	Rich city near the Ocean Sea, with salt production.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
69	Tongzhou	Tongzhou (Jiangsu)	Tongzhou	32.084	121.06	city	\N	City producing vast amounts of salt.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
70	Yangzhou	Yangzhou	Yangzhou	32.3942	119.413	city	\N	Major city governed by Marco Polo for three years.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
71	Anqing	Anqing	Anqing	30.5428	117.0631	region	\N	Wealthy province with silk and lions.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
72	Xiangyangfu	Xiangyang	Xiangyangfu	32.012	112.121	city	\N	City that held out for three years until trebuchets arrived.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
73	Zhenzhou	Zhenjiang	Zhenzhou	32.1889	119.4255	city	\N	Major shipping center on the Yangtze.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
74	Yangtze	Yangtze River	Yangtze	0	0	river	\N	The greatest river in the world, with immense shipping.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
75	Guazhou	Guazhou	Guazhou	32.415	119.256	city	\N	City storing grain for the Great Khan's court.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
76	Zhenjiangfu	Zhenjiang	Zhenjiangfu	32.1889	119.4255	city	\N	City with Nestorian churches built in 1278.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
77	Changzhou	Changzhou	Changzhou	31.7714	119.9549	city	\N	City where Alans were massacred by locals.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
78	Suzhou	Suzhou	Suzhou	31.2989	120.5853	city	\N	Vast city with 6,000 stone bridges and 16 subject cities.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
79	Wujiang	Wujiang	Wujiang	31.137	120.638	city	\N	Large prosperous city near Suzhou.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
80	Wuxing	Wuxing	Wuxing	30.895	120.097	city	\N	Splendid city with silk and precious wares.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
81	Changxing	Changxing	Changxing	31.006	119.952	city	\N	Large city producing sendal fabrics.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
82	Tonglu	Tonglu	Tonglu	29.7934	119.6865	city	\N	Big city under Xingzai's jurisdiction.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
83	Wuzhou	Wuzhou	Wuzhou	23.481	111.3155	city	\N	Large city under Xingzai's jurisdiction.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
84	Quzhou	Quzhou	Quzhou	28.9417	118.8786	city	\N	Big city with abundant means of life.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
85	Suichang	Suichang	Suichang	28.5727	118.9305	city	\N	City on a hill dividing a river.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
86	Chuzhou	Chuzhou (Zhejiang)	Chuzhou	28.7695	118.8885	city	\N	Last city under Xingzai, gateway to Fuzhou.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
87	Fuzhou	Fuzhou (Fujian)	Fuzhou	26.0745	119.2965	city	\N	Capital of a kingdom, with a bridge and sugar trade.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
88	Jianningfu	Nanping	Jianningfu	26.6359	118.1767	city	\N	City with three magnificent stone bridges.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
89	Houguan	Houguan	Houguan	0	0	city	\N	City producing sugar for the Great Khan's court.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
90	Zayton	Quanzhou	Zayton	24.8745	118.6756	port	\N	One of the world's busiest ports, major trade hub.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
91	Tingzhou	Tingzhou	Tingzhou	25.8019	116.358	city	\N	City famous for producing porcelain bowls.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
92	Maabar	Coromandel Coast, India	Maabar	20.5937	78.9629	region	\N	A wealthy province in Greater India known for pearl fishing and trade.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
93	Ceylon	Sri Lanka	Ceylon	7.8731	80.7718	island	\N	An island near Maabar, mentioned as a reference point for travel.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
94	Male Island	\N	Male Island	0	0	island	\N	An island in the Arabian Sea inhabited by baptized Christians with a unique social custom separating men and women.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
95	Female Island	\N	Female Island	0	0	island	\N	The island where the wives of Male Island residents live, about 30 miles away.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
96	Kesh-Makran	Makran	Kesh-Makran	0	0	region	\N	A coastal region in Balochistan, used as a reference point for the location of Male Island.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
97	Turkestan	Central Asia (covering modern Kazakhstan, Uzbekistan, etc.)	Turkestan	40	60	region	\N	Region in Central Asia ruled by Qaidu, stretching north of the Gihon River towards the Great Khan's dominions.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
98	Karakorum	Kharkhorin, Mongolia	Karakorum	47.1833	102.8167	city	\N	Ancient capital of the Mongol Empire where Nomuqan and George were stationed.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
99	Samarkand	Samarkand, Uzbekistan	Samarkand	39.6542	66.9597	city	\N	Capital city in Turkestan where Qaidu returned to rule after battles.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
100	Dry Tree	Solitary Tree region	Dry Tree / Solitary Tree	38	58	region	\N	Region near the Gihon River bordering the Levant and Turkestan, site of military standoffs.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
101	Gihon	Amu Darya (Oxus River)	Gihon / Oxus	41.5	58	river	\N	Major river forming a boundary between Turkestan and the Levant territories.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
102	Levant	Ilkhanate (modern Iran/Middle East)	Levant (under Mongol rule)	33	45	region	\N	Mongol-ruled territory in the Middle East, ruled by Abagha and later Arghun.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
103	Rudbar	Rudbar	Rudbar	36.5333	49.5833	region	\N	A region mentioned in the text, possibly in modern-day Iran or Afghanistan.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
104	Daidu	Beijing	Daidu	39.9042	116.4074	city	\N	Capital city of the Mongol Yuan dynasty in China.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
105	Trebizond	Trabzon	Trebizond	41.0027	39.7168	city	\N	Ancient Silk Route city on the Black Sea coast.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
106	Taleqan	Taleqan, Afghanistan	Dogava/Taican	36.75	69.54	city	\N	A city in northeastern Afghanistan on the route to Badakhshan.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
107	Iskashim	Ishkoshim, Tajikistan	Scassem	36.7269	71.6114	city	\N	A town on the Panj River, now in Tajikistan, on the border with Afghanistan.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
108	Badakhshan	Badakhshan Province, Afghanistan	Badascian	37	71	region	\N	A historical region and province in northeastern Afghanistan and southeastern Tajikistan.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
109	Wakhan	Wakhan Corridor, Afghanistan	Vocan	37	73	region	\N	A narrow strip of territory in northeastern Afghanistan, part of the ancient Silk Road.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
110	Pashai	Pashai region, Afghanistan	Pasciai	35	70	region	\N	A region mentioned in a digression, likely in eastern Afghanistan.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
111	Kashmir	Kashmir Valley, India	Chescemir	34.0837	74.7973	region	\N	A valley in the Himalayas, a major historical kingdom.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
112	Kingdom of Braaman	\N	Braaman	0	0	other	\N	A legendary kingdom, possibly referring to a land of Brahmins in India.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
113	Madagascar	Mogadishu, Somalia / Horn of Africa	Madeigascar / Mogdaxo	2.0469	45.3182	region	\N	Marco Polo's 'island' misidentified, likely referring to the Horn of Africa or Mogadishu.	\N	\N	\N	\N	2026-05-06 00:38:29.282719+08	2026-05-06 00:38:29.282719+08	\N	\N
\.


--
-- Data for Name: relation_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relation_locations (id, from_location_id, to_location_id, relation_type, description) FROM stdin;
\.


--
-- Name: authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.authors_id_seq', 1, false);


--
-- Name: books_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.books_id_seq', 1, false);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entries_id_seq', 30, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.locations_id_seq', 113, true);


--
-- Name: relation_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.relation_locations_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: entry_authors entry_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry_authors
    ADD CONSTRAINT entry_authors_pkey PRIMARY KEY (entry_id, author_id);


--
-- Name: entry_locations entry_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry_locations
    ADD CONSTRAINT entry_locations_pkey PRIMARY KEY (entry_id, location_id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: relation_locations relation_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relation_locations
    ADD CONSTRAINT relation_locations_pkey PRIMARY KEY (id);


--
-- Name: entry_authors entry_authors_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry_authors
    ADD CONSTRAINT entry_authors_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE CASCADE;


--
-- Name: entry_authors entry_authors_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry_authors
    ADD CONSTRAINT entry_authors_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.journal_entries(id) ON DELETE CASCADE;


--
-- Name: entry_locations entry_locations_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry_locations
    ADD CONSTRAINT entry_locations_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.journal_entries(id) ON DELETE CASCADE;


--
-- Name: entry_locations entry_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entry_locations
    ADD CONSTRAINT entry_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: journal_entries journal_entries_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id);


--
-- Name: relation_locations relation_locations_from_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relation_locations
    ADD CONSTRAINT relation_locations_from_location_id_fkey FOREIGN KEY (from_location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: relation_locations relation_locations_to_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relation_locations
    ADD CONSTRAINT relation_locations_to_location_id_fkey FOREIGN KEY (to_location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Zzv2nr9AwbTjk1Pzr4ie5jXL3hd0XLvfIdjTJTgPwRedVUhHwB2zWzM44fSq9zC

